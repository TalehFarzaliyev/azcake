<?php


namespace App\Classes;


class Example
{

}
