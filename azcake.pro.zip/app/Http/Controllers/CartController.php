<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\SingleProductAttributes;
use Darryldecode\Cart\Cart;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CartController extends Controller
{
    /**
     * @return Application|Factory|View
     */
    public function index() {
        $cartCollection = \Cart::getContent();

        return view('site.pages.cart',[
            'products' => $cartCollection
        ]);
    }

    public function changeQuantity(Request $request){

        $id = $request->get('id');
        $quantitiy = $request->get('quantity');



        \Cart::update($id,[
            'quantity' => +1,
        ]);

        return response()->json([
            'status'  => true,
            'products' => \Cart::getContent()->toArray()
        ]);

    }

    public function storeCart(Request $request){

        $product = Product::find($request->get('product_id'));

        $price = $product['price'];
        if ($product){

            $product_attribute_id = null;

            $product_attribute = null;

            if ($request->get('single_product_attribute_id')){
                $product_attribute_id = $request->get('attribute_id') ?? $request->get('single_product_attribute_id');
                $product_attribute = SingleProductAttributes::find($product_attribute_id);
                if ($product_attribute){
                    $price = $product_attribute['price'];
                }
            }

            \Cart::add(array(
                'id' => $product_attribute_id ? $product['id'].'-'.$product_attribute_id : $product['id'].'-0',
                'name' => $product->name,
                'price' => $price,
                'quantity' => $request->get('quantity',1),
                'attributes' => array(
                    'product_slug' => $product['slug'],
                    'product_id' => $product['id'],
                    'attribute_id' => $product_attribute_id,
                    'product_attribute' => $product_attribute
                ),
                'associatedModel' => $product
            ));



            return response()->json([
                'status'  => true,
                'products' => \Cart::getContent()->toArray()
            ]);
        }

        return response()->json([
            'status'  => false,
            'message' => 'Product not found'
        ]);

    }
}
